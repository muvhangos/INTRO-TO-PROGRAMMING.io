// Try It Out : Page 17
(15 + 9) * 2 

// Try It Out : Page 23
var balloons = 100;
balloons *= 2;
// 200

var balloons = 100;
balloons /= 4;

// Try It Out : Page 37
var age = 12;
var accompanied = true;

if (age  >= 13 || accompanied) {
    console.log("Allowed to see the movie");
}
else{
    console.log("Not allowed to see the movie");
}