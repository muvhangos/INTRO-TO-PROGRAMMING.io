// 1: Scorekeeper
let scores = {
    'Alex': 0,
    'Ethan': 0,
    'Sam': 0,
    'Liam': 0,
    'Ava': 0
};

scores['Ethan'] = 3;
scores['Ethan'] += 2;
console.log(scores);

//2: Digging into Objects and Arrays
/* 
var myCrazyObject = {
    "name": "A ridiculous object",
    "some array": [7, 9, { purpose: "confusion", number: 123 }, 3.3],
    "random animal": "Banana Shark"
    };
console.log(myCrazyObject["some array"][2].number); 
*/