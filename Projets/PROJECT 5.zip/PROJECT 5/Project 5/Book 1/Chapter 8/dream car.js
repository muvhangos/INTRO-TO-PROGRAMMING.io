var dreamCar = {
    make: "Oldsmobile",
    model: "1980",
    color: "brown",
    year: 1975,
    bodyStyle: "Luxury Car",
    price: 500 000.00
   };

   alert("The type of dreamCar is: " + typeof dreamCar);

// document.getElementById("pricetag").innerHTML = dreamCar.price;
// document.getElementById("modelyear").innerHTML = dreamCar.year;
// document.getElementById("body").style.backgroundColor = dreamCar.color;
// document.getElementById("body").innerHTML = dreamCar.make + " " + dreamCar.model;